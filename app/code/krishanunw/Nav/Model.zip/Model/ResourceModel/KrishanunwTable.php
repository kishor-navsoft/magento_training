<?php 
namespace Krishanu\Nav\ModelResourceModel;
class KrishanunwTable extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb{
 public function _construct(){
 $this->_init("krishanunw_table","id");
 }
}
 ?>