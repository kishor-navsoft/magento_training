<?php 
namespace Krishanu\Nav\ModelResourceModel\KrishanunwTable;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{
	public function _construct(){
		$this->_init("Krishanu\Nav\KrishanunwTable","Krishanu\Nav\ModelResourceModel\KrishanunwTable");
	}
}
 ?>