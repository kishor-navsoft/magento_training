<?php 
namespace Krishanu\Nav\Model;
class KrishanunwTable extends \Magento\Framework\Model\AbstractModel{
	public function _construct(){
		$this->_init("Krishanu\Nav\Model\ResourceModel\KrishanunwTable");
	}
}
 ?>